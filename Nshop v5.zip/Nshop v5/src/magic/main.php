<?php

namespace magic;

use onebone\economyapi\EconomyAPI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\item\Item;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use magic\utils\API;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\inventory\PlayerInventory;
#写注释是不可能的这辈子都不可能的
class main extends PluginBase implements Listener{
	public function onEnable()
		{ 
$this->o1=null;
$this->o2=null;
$this->o3=null;
$this->t1=null;
$this->t2=null;
$this->t3=null;
$this->y1=null;
$this->y2=null;
$this->y3=null;
$this->y4=null;
$this->y5=null;
        $this->api = new API($this);
        $this->saveDefaultConfig();
        $this->reloadConfig();
        if(!file_exists($this->getDataFolder())) @mkdir($this->getDataFolder(), 0744, true);
        $this->config = new Config($this->getDataFolder()."config.yml", Config::YAML);
			$this->getServer()->getPluginManager()->registerEvents($this,$this);

if(!is_dir($this->getDataFolder())) mkdir($this->getDataFolder());
		$this->shou = new Config($this->getDataFolder()."购买.yml", Config::YAML, 
            [ 
          "1:0"=>
       [
         "price"=>20,
         "note"=>"石头",
       ]
]);
$this->shou->save();


if(!is_dir($this->getDataFolder())) mkdir($this->getDataFolder());
		$this->mai = new Config($this->getDataFolder()."回收.yml", Config::YAML, 
		[
           "1:0"=>
       [
         "price"=>20,
         "note"=>"石头",
       ]
            ]);
$this->mai->save();

if(!is_dir($this->getDataFolder())) mkdir($this->getDataFolder());
		$this->sui = new Config($this->getDataFolder()."指令.yml", Config::YAML, 
		[
           "kill @p"=>
       [
         "price"=>20,
         "note"=>"死！！！",
       ]
            ]);
$this->sui->save();

if(!is_dir($this->getDataFolder())) mkdir($this->getDataFolder());
		$this->yan = new Config($this->getDataFolder()."经验.yml", Config::YAML, 
		[
           "1"=>
       [
         "price"=>20,
         "note"=>"购买一点经验",
       ]
            ]);
$this->yan->save();

if(!is_dir($this->getDataFolder())) mkdir($this->getDataFolder());
		$this->mo = new Config($this->getDataFolder()."附魔.yml", Config::YAML, 
		[
           "0:1"=>
       [
         "price"=>20,
         "note"=>"保护一一级",
       ]
            ]);
$this->mo->save();

if(!is_dir($this->getDataFolder())) mkdir($this->getDataFolder());
		$this->open = new Config($this->getDataFolder()."开关.yml", Config::YAML, 
           [
     "出售商店开关"=>"open",
     "回收商店开关"=>"open",
     "指令商店开关"=>"open",
     "经验商店开关"=>"open",
     "附魔商店开关"=>"open",
     "兑换商店开关"=>"open",
          ]);

if(!is_dir($this->getDataFolder())) mkdir($this->getDataFolder());
		$this->huan = new Config($this->getDataFolder()."兑换.yml", Config::YAML, 
		[
           "1:0"=>
       [
         "item"=>"2:0:2",
         "cmd"=>"kill @p",
         "note"=>"石头",
       ]
            ]);
$this->huan->save();

  			$this->getLogger()->info("===============================");
		$this->getLogger()->info("本插件由渣渣土乱写出来");
              $this->getLogger()->info("本插件虽然辣鸡但禁止盗卖与乱改版权");
              $this->getLogger()->info("本插件作者渣渣土   QQ✑1010340249");
		$this->getLogger()->info("===============================");
}

public function onReceive(DataPacketReceiveEvent $e)
	{
$kan= $this->shou->getAll();
$kant= $this->mai->getAll();
$kand= $this->sui->getAll();
$kanj= $this->yan->getAll();
$kanm= $this->mo->getAll();
$kanz= $this->huan->getAll();
	$pk = $e->getPacket();
		$player = $e->getPlayer();
		if (!($pk instanceof ModalFormResponsePacket)) return;
$id = $pk->formId;
$data = json_decode($pk->formData);

switch ($id) { 
	case 0:
	if ($pk->formData == "null\n")return;
if((int)$data == 0){
    	$this->getAPI()->fuck(1, $player);
       return;
 }
if((int)$data == 1){
    	$this->getAPI()->fuck(2, $player);
					return;
   }
if((int)$data == 2){
    	$this->getAPI()->fuck(3, $player);
					return;
   }
if((int)$data == 3){
    	$this->getAPI()->fuck(4, $player);
					return;
   }
if((int)$data == 4){
    	$this->getAPI()->fuck(5, $player);
					return;
   }
if((int)$data == 5){
    	$this->getAPI()->fuck(8, $player);
					return;
   }
break;


case 1:
	if ($pk->formData == "null\n")return;
$m = array_keys($kan)[$data];
$cao=$this->shou->get($m)["price"];
$key = array_keys($kan)[$data];
$sm=explode(":",$key);
$this->getAPI()->fuck(6, $player);
$this->o1=$cao;
$this->o2=$sm[0];
$this->o3=$sm[1];
break;

case 6:
if($data[0]<=0){
$player->sendMessage("§3请不要随意输入数值");
return false;
}
$cao=$this->o1*$data[0];
$mym = EconomyAPI::getInstance()->myMoney($player->getName());
if ($cao > $mym){
    $player->sendMessage("§4对不起你的钱不够");
return false;
}
EconomyAPI::getInstance()->reduceMoney($player, $cao);

$player->getInventory()->addItem(Item::get($this->o2, $this->o3,$data[0]));
    $player->sendMessage("§l§3恭喜你购买成功,§5本次花费了{$cao}");
unset($cao);
break;

case 2:
if ($pk->formData == "null\n")return;
$haixing = array_keys($kant)[$data];
$hhh = array_keys($kant)[$data];
$wocao=$this->mai->get($hhh)["price"];
$rbq=explode(":",$haixing);
$this->t1=$rbq[0];
$this->t2=$rbq[1];
$this->t3=$wocao;
$this->getAPI()->fuck(7, $player);
break;

case 7:
if($data[0]<=0){
$player->sendMessage("§3请不要随意输入数值");
return false;
}
$emmm=$this->t3*$data[0];
if(!$player->getInventory()->contains(Item::get($this->t1,$this->t2,$data[0]))){
$player->sendMessage("§l§4您的物品不足");
            return false;
        }
EconomyAPI::getInstance()->addMoney($player, $emmm);
$player->getInventory()->removeItem(Item::get($this->t1,$this->t2,$data[0]));
    $player->sendMessage("§l§7恭喜你出售成功,§5本次获得了{$emmm}");
unset($emmm);
break;

case 3:
if ($pk->formData == "null\n")return;
$m = array_keys($kand)[$data];
$cao=$this->sui->get($m)["price"];
$mym = EconomyAPI::getInstance()->myMoney($player->getName());
if ($cao > $mym){
    $player->sendMessage("§4对不起你的钱不够");
return false;
}

$b = array_keys($kand)[$data];
$wori=$this->sui->get($b)["price"];
EconomyAPI::getInstance()->reduceMoney($player, $wori);

$key = array_keys($kand)[$data];
$kee = (string)$key;
$com = str_replace("@p",$player->getName(), $kee);
Server::getInstance()->dispatchCommand(new ConsoleCommandSender(),$com);
    $player->sendMessage("§l§3恭喜你购买成功,§5本次花费了{$wori}");
break;

case 4:
if ($pk->formData == "null\n")return;
$m = array_keys($kanj)[$data];
$cao=$this->yan->get($m)["price"];
$mym = EconomyAPI::getInstance()->myMoney($player->getName());
if ($cao > $mym){
    $player->sendMessage("§4对不起你的钱不够");
return false;
}

$b = array_keys($kanj)[$data];
$wori=$this->yan->get($b)["price"];
EconomyAPI::getInstance()->reduceMoney($player, $wori);

$key = array_keys($kanj)[$data];
$kee = (int)$key;
$player->addXp($kee);
    $player->sendMessage("§l§3恭喜你购买成功,§5本次花费了{$wori}");
break;

case 5:
if ($pk->formData == "null\n")return;

$m = array_keys($kanm)[$data];
$cao=$this->mo->get($m)["price"];
$mym = EconomyAPI::getInstance()->myMoney($player->getName());
if ($cao > $mym){
    $player->sendMessage("§4对不起你的钱不够");
return false;
}

$key = array_keys($kanm)[$data];
$sm=explode(":",$key);
$bg=$player->getInventory()-> getHotbarSlotItem(1);
if($bg->getID() == 0)
return $player->sendMessage("§l§1未发现附魔物品");
if($bg->getCount() > 1) 
return $player->sendMessage("§c只能附魔一个物品喔!");
$enchid = Enchantment::getEnchantment($sm[0]);
$ench =  new EnchantmentInstance($enchid, $sm[1] + 0);
$bg->addEnchantment($ench);
$player->getInventory()->setItem(1,$bg);
$b = array_keys($kanm)[$data];
$wori=$this->mo->get($b)["price"];
EconomyAPI::getInstance()->reduceMoney($player, $wori);
$player->sendMessage("§l§3恭喜你购买成功,§5本次花费了{$wori}");
break;

case 8:
if ($pk->formData == "null\n")return;

$this->getAPI()->fuck(9, $player);
$i = array_keys($kanz)[$data];
$cao=$this->huan->get($i)["item"];
$aaa=$this->huan->get($i)["cmd"];
$rbq=explode(":",$i);
$this->y1=$rbq[0];
$this->y2=$rbq[1];
$this->y3=$cao;
$this->y4=$aaa;
break;

case 9:
if($data[0]<=0){
$player->sendMessage("§3请不要随意输入数值");
return false;
}
$gggg=explode(":",$this->y3);
if(!$player->getInventory()->contains(Item::get($gggg[0],$gggg[1],$data[0]*$gggg[2]))){
$player->sendMessage("§l§4您的物品不足");
            return false;
        }
$player->getInventory()->addItem(Item::get($this->y1, $this->y2,$data[0]));

$player->getInventory()->removeItem(Item::get($gggg[0],$gggg[1],$data[0]*$gggg[2]));

$kee = (string)$this->y4;
$com = str_replace("@p",$player->getName(), $kee);
Server::getInstance()->dispatchCommand(new ConsoleCommandSender(),$com);

  $player->sendMessage("§l§3恭喜你兑换成功");
break;
}
}

public function getshou($a){
	return $this->shou->get($a);
	}
public function getshouall(){
	return $this->shou->getAll();
	}
public function getmai($a){
	return $this->mai->get($a);
	}
public function getmaiall(){
	return $this->mai->getAll();
	}
public function getsui($a){
	return $this->sui->get($a);
	}
public function getsuiall(){
	return $this->sui->getAll();
	}
public function getyan($a){
	return $this->yan->get($a);
	}
public function getyanall(){
	return $this->yan->getAll();
	}
public function getmo($a){
	return $this->mo->get($a);
	}
public function getmoall(){
	return $this->mo->getAll();
	}
public function getopen($a){
	return $this->open->get($a);
	}
public function gethuan($a){
	return $this->huan->get($a);
	}
public function gethuanall(){
	return $this->huan->getAll();
	}


public function onBlockTap(PlayerInteractEvent $event)
    {
        $player = $event->getPlayer();
        $item=$event->getItem();
    if($item->getID() == 370 and $item->getDamage() == 99){
    $this->getAPI()->fuck(0, $player);
    $event->setCancelled(true);
        }
}

public function onJoin(PLayerJoinEvent $event)
{
       $player = $event->getPlayer();
	foreach ($player->getInventory()->getContents() as $item) {
if($item->getId() == 370 AND $item->getDamage() == 99)
return;
}
$player->getInventory()->addItem($this->zh());
$player->sendMessage("§l§8商店UI§l§6召唤工具已经送到您的背包里");
}

public function zh(){
$item =new Item(370,99);
$item->setCustomName("§b商店");
return $item;
}

public function getUi($player){
     $this->getAPI()->fuck(0, $player);
    }
public function getcfg($a){
	return $this->config->get($a);
	}
public function getAPI()
    {
        return $this->api;
    }
}
#啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊

