<?php
namespace magic\utils;

use pocketmine\Server;
use
pocketmine\network\mcpe\protocol\ModalFormRequestPacket;
use magic\main;


class API
{
private $plugin;

const ZHU = 0;
const SHOU = 1;
const MAI = 2;
const SUI = 3;
const YAN = 4;
const MO = 5;
const ONE = 6;
const TWO = 7;
const HUAN = 8;
const THREE = 9;
public function __construct($plugin)
	{
		$this->plugin = $plugin;
	}


public function fuck($formId, $player)
	{
switch($formId){
case 0:
$json= $this->zhu($player);
break;
case 1:
$json= $this->shou();
break;
case 2:
$json= $this->mai();
break;
case 3:
$json= $this->sui();
break;
case 4:
$json= $this->yan();
break;
case 5:
$json= $this->mo();
break;
case 6:
$json = $this->one();
break;
case 7:
$json = $this->two();
break;
case 8:
$json = $this->huan();
break;
case 9:
$json = $this->three();
break;
}
	$pk = new ModalFormRequestPacket();
        $pk->formId = $formId;
        $pk->formData = $json;
        $player->dataPacket($pk);
}

public function zhu($p){
	$data = [];
$open1= $this->plugin->getopen("出售商店开关");
$open2= $this->plugin->getopen("回收商店开关");
$open3= $this->plugin->getopen("指令商店开关");
$open4= $this->plugin->getopen("经验商店开关");
$open5= $this->plugin->getopen("附魔商店开关");
$open6= $this->plugin->getopen("兑换商店开关");
		$data["type"] = "form";
		$data["title"] = $this->plugin->getcfg("zhu_ui_title");
$data["content"] = $this->plugin->getcfg("zhu_ui_content");

switch($open1){
case "open":
	$a["text"] = $this->plugin->getcfg("zhu_ui_text1");
		$a["image"]["type"] = "path";
		$a["image"]["data"] = 'textures/items/minecart_furnace';
$data["buttons"][] = $a;
break;
}

switch($open2){
case "open":
	$b["text"] = $this->plugin->getcfg("zhu_ui_text2");
		$b["image"]["type"] = "path";
		$b["image"]["data"] = 'textures/items/minecart_chest';
$data["buttons"][] = $b;
break;
}

switch($open3){
case "open":
	$c["text"] = $this->plugin->getcfg("zhu_ui_text3");
		$c["image"]["type"] = "path";
		$c["image"]["data"] = 'textures/items/minecart_hopper';
$data["buttons"][] = $c;
break;
}

switch($open4){
case "open":
        $d["text"] = $this->plugin->getcfg("zhu_ui_text4");
		$d["image"]["type"] = "path";
		$d["image"]["data"] = 'textures/items/minecart_tnt';
$data["buttons"][] = $d;
break;
}

switch($open5){
case "open":
$e["text"] = $this->plugin->getcfg("zhu_ui_text5");
		$e["image"]["type"] = "path";
		$e["image"]["data"] = 'textures/items/minecart_normal';
$data["buttons"][] = $e;
break;
}

switch($open6){
case "open":
$r["text"] = $this->plugin->getcfg("zhu_ui_text6");
		$r["image"]["type"] = "path";
		$r["image"]["data"] = 'textures/items/name_tag';
$data["buttons"][] = $r;
break;
}

$json = $this->getEncodedJson($data);
return $json;
}


public function shou(){
$key = array_keys($this->plugin->getshouall());
	$data = [];
		$data["type"] = "form";
		$data["title"] = $this->plugin->getcfg("shou_ui_title");
$data["content"] = $this->plugin->getcfg("shou_ui_content");
foreach ($key as $keys){
$a["text"] = "§4购买".$this->plugin->getshou($keys)["note"]."\n§l§3单价".$this->plugin->getshou($keys)["price"];
$data["buttons"][] =$a;
}
$json = $this->getEncodedJson($data);
		return $json;
}

public function mai(){
$key = array_keys($this->plugin->getmaiall());
	$data = [];
		$data["type"] = "form";
		$data["title"] = $this->plugin->getcfg("mai_ui_title");
$data["content"] = $this->plugin->getcfg("mai_ui_content");
foreach ($key as $keys){
$a["text"] = "§4出售".$this->plugin->getmai($keys)["note"]."\n§l§3单价".$this->plugin->getmai($keys)["price"];
$data["buttons"][] =$a;
}
$json = $this->getEncodedJson($data);
		return $json;
}

public function sui(){
$key = array_keys($this->plugin->getsuiall());
	$data = [];
		$data["type"] = "form";
		$data["title"] = $this->plugin->getcfg("sui_ui_title");
$data["content"] = $this->plugin->getcfg("sui_ui_content");
foreach ($key as $keys){
	$a["text"] = $this->plugin->getsui($keys)["note"]."\n§l§3价格".$this->plugin->getsui($keys)["price"];
$data["buttons"][] = $a;
}
$json = $this->getEncodedJson($data);
		return $json;
}

public function yan(){
$key = array_keys($this->plugin->getyanall());
	$data = [];
		$data["type"] = "form";
		$data["title"] = $this->plugin->getcfg("yan_ui_title");
$data["content"] = $this->plugin->getcfg("yan_ui_content");
foreach ($key as $keys){
	$a["text"] = $this->plugin->getyan($keys)["note"]."\n§l§3价格".$this->plugin->getyan($keys)["price"];
$data["buttons"][] = $a;
}
$json = $this->getEncodedJson($data);
		return $json;
}

public function mo(){
$key = array_keys($this->plugin->getmoall());
	$data = [];
		$data["type"] = "form";
		$data["title"] = $this->plugin->getcfg("mo_ui_title");
$data["content"] = $this->plugin->getcfg("mo_ui_content")."\n§6记得将要附魔的物品放在§3第二个§6物品栏哦";
foreach ($key as $keys){
	$a["text"] = $this->plugin->getmo($keys)["note"]."\n§l§3价格".$this->plugin->getmo($keys)["price"];
$data["buttons"][] = $a;
}
$json = $this->getEncodedJson($data);
		return $json;
}

public function huan(){
$key = array_keys($this->plugin->gethuanall());
	$data = [];
		$data["type"] = "form";
		$data["title"] = $this->plugin->getcfg("huan_ui_title");
$data["content"] = $this->plugin->getcfg("huan_ui_content");
foreach ($key as $keys){
	$a["text"] = $this->plugin->gethuan($keys)["note"]."\n§l§3需要物品".$this->plugin->gethuan($keys)["item"];
$data["buttons"][] = $a;
}
$json = $this->getEncodedJson($data);
		return $json;
}


public function one(){
	$data = [];
		$data["type"] = "custom_form";
		$data["title"] = "§l§3输入你要的数量";
			$content[0]["type"] = "input";
				$content[0]["text"] = "需要购买的数量:";
$data["content"] =$content;
	$json = $this->getEncodedJson($data);
		return $json;
	}

public function two(){
	$data = [];
		$data["type"] = "custom_form";
		$data["title"] = "§l§3输入你要的数量";
			$content[0]["type"] = "input";
				$content[0]["text"] = "需要出售的数量:";
$data["content"] =$content;
	$json = $this->getEncodedJson($data);
		return $json;
	}

public function three(){
	$data = [];
		$data["type"] = "custom_form";
		$data["title"] = "§l§3输入你要的数量";
			$content[0]["type"] = "input";
				$content[0]["text"] = "需要兑换的数量:";
$data["content"] =$content;
	$json = $this->getEncodedJson($data);
		return $json;
}

public function getEncodedJson($data)
	{
		return json_encode($data, JSON_PRETTY_PRINT | JSON_BIGINT_AS_STRING | JSON_UNESCAPED_UNICODE);
	}
}






	